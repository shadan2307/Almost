import React, { useEffect, useState } from 'react';

const TelegramLogin = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://telegram.org/js/telegram-widget.js?19';
    script.async = true;
    script.setAttribute('data-telegram-login', 'Hypercube_tech_bot');
    script.setAttribute('data-size', 'large');
    script.setAttribute('data-auth-url', 'https://services-tsax.onrender.com/auth');
    script.setAttribute('data-request-access', 'write');
    document.getElementById('telegram-login').appendChild(script);

    window.addEventListener('message', (event) => {
      if (event.origin === 'https://telegram.org') {
        const { id, username, first_name, last_name, photo_url, auth_date } = event.data;
        setUser({ id, username, first_name, last_name, photo_url, auth_date });
      }
    });
  }, []);

  return (
    <div>
      <div id="telegram-login"></div>
      {user && (
        <div>
          <h2>Welcome, {user.username}!</h2>
          <p>ID: {user.id}</p>
          <p>Name: {user.first_name} {user.last_name}</p>
          {user.photo_url && <img src={user.photo_url} alt="Profile" />}
        </div>
      )}
    </div>
  );
};

export default TelegramLogin;

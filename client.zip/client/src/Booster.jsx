import React from 'react'
import { useEffect, useState } from 'react';
import highVoltage from '../public/high-voltage.png';
import './Booster.css'
const Booster = () => {

    const [energy, setEnergy] = useState(1);
    const [limit, setlimit] = useState(500)
    const [speed, setspeed] = useState(500)

    useEffect(() => {
        const interval = setInterval(() => {
            setEnergy((prevEnergy) => Math.min(prevEnergy + 1, limit));
        }, speed);
        return () => clearInterval(interval);
    }, []);

    const test = () => {
        if (energy < 0) {

        } else {
            setEnergy(pre => pre - 20)
        }


    }


    const testEnergy = () => {
        setlimit(2500)

    }

    const testMinus = () => {
        setEnergy(pre => pre - 2)

    }

    const testSpeed = () => {
        const interval = setInterval(() => {
            setEnergy((prevEnergy) => Math.min(prevEnergy + 1, limit));
        }, 50);
        return () => clearInterval(interval);

    }

    return (
        <>


            <div style={{ backgroundColor: '', width: '200px' }}>


                <div >
                    <div style={{ display: 'flex' }} >
                        <img src={highVoltage} width="30" height="30" alt="High Voltage" />
                        <div >
                            <span>{energy}</span>
                            <span>/ {limit}</span>
                        </div>
                    </div>
                </div>

                <div style={{ backgroundColor: '#f9c035', borderRadius: '9px' }} >
                    <div className='progress-fill' style={{ width: `${(energy / limit) * 100}%`, backgroundColor: '' }}></div>
                </div>


            </div>

            {/* <div className='button' onClick={testEnergy} style={{ padding: '10px', background: "", color: 'white', display: 'flex', justifyContent: 'center', alignItems: "center", cursor: 'pointer', border: '1px solid #434343', borderRadius: '8px' }}> Energy Limit</div>
            <div className='button' onClick={testSpeed} style={{ padding: '10px', background: "", color: 'white', display: 'flex', justifyContent: 'center', alignItems: "center", cursor: 'pointer', border: '1px solid #434343', borderRadius: '8px' }}> recharge Speed</div>
            <div className='button' onClick={testMinus} style={{ padding: '10px', background: "", color: 'white', display: 'flex', justifyContent: 'center', alignItems: "center", cursor: 'pointer', border: '1px solid #434343', borderRadius: '8px' }}> Get Coin</div> */}


        </>
    )
}

export default Booster
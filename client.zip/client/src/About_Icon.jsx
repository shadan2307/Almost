import React, { useState } from 'react'
import About from './About';
import ab1 from '../public/ab2.png'
const About_Icon = () => {
    const [about, setabout] = useState(0);
    const showAbout = () => {
        setabout(1)

    }
    const offAbout = () => {
        setabout(0)

    }
    return (
        <>
            <div onClick={showAbout} style={{ position: 'absolute', right: '30px', top: '50px', cursor: 'pointer' }}> <img src={ab1} height={"20px"} alt="" /></div>
            {about ? <About close={offAbout} /> : <></>}
        </>
    )
}

export default About_Icon
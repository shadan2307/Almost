import { useState, useEffect } from 'react'
import './App.css'
import coin from '../public/coin2.png'
import c from '../public/c.png'
import g from '../public/g.png'
import f from '../public/f.png'
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Task from './Task'
import Apps from './Apps'
import Stat from './Stat'
import Boost from './Boost'
import t from '../public/t.png'
import s from '../public/s.png'
import Home from './Home'
import r from '../public/r.png'
import Footer from './Footer'
import Levels from './Levels'
import { v4 as uuidv4 } from 'uuid';
import Referral from './Referral'
import Youtube from './Youtube'
import DailyTask from './DailyTask'
import Follow from './Follow'
function App() {

  useEffect(() => {

    const referralID = new URLSearchParams(window.location.search).get('referral_id');

    if (referralID) {
      console.log("THIS IS YOUR Referral ID ", referralID)
    } else {
      console.log("You Joined Without Referral ID")
    }
    if (localStorage.getItem('userid')) {

    } else {
      const id = uuidv4().slice(0, 7);
      console.log("THis is your ID ", id)
      localStorage.setItem('userid', id);
    }


  }, [])

  return (
    <>
      <Router>

        <Routes>
          <Route path="/" element={<Home />} >
            <Route path="/home" element={<Apps />} />
            <Route path="/levels" element={<Levels />} />
            <Route path="/task" element={<Task />} >
              <Route path="/task/ref" element={<Referral />} />
              <Route path="/task/vid" element={<Youtube />} />
              <Route path="/task/follow" element={<Follow />} />
              <Route path="/task/dailytask" element={<DailyTask />} />
            </Route>
            <Route path="/stat" element={<Stat />} />
            <Route path="/boost" element={<Boost />} />
          </Route>
        </Routes>

      </Router>

    </>
  )
}

export default App

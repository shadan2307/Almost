import React from 'react'
import Footer from './Footer'
import { Link } from 'react-router-dom'
import g from '../public/g.png'
import DailyTask from './DailyTask'
import { useEffect, useState } from 'react'

const Stat = () => {
  const [userid, setuserid] = useState(0)
  const dummpyData = ['rohan', 'sameer', 'farhan', 'saher']
  useEffect(() => {


    if (localStorage.getItem('userid')) {
      setuserid(localStorage.getItem('userid'));
      console.log(localStorage.getItem('userid'))
      setText(`http://localhost:5173/?referral_id=${localStorage.getItem('userid')}`)
    }

  }, [])

  const [text, setText] = useState(0);

  const copyTextToClipboard = () => {
    navigator.clipboard.writeText(text).then(() => {

      alert('Text copied to clipboard!');

    }).catch((err) => {
      console.error('Could not copy text: ', err);
    });
  };
  return (
    <>
      <div style={{ display: 'flex', flexDirection: "column", gap: '20px' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', justifyContent: 'center', alignContent: 'center' }}>
          <input disabled type="text" value={`http://localhost:5173/?referral_id=${userid}`} />
          <button className='button' style={{ cursor: 'pointer', border: 'none', padding: '10px', backgroundColor: '#F1B658' }} onClick={copyTextToClipboard} >Share</button> </div>

        <div>Your Referrals :</div>
        <div style={{ display: 'flex', flexDirection: "column", gap: '10px', overflow: '' }}>
          {dummpyData && dummpyData.map((e) => {
            return <div className='button' style={{ display: 'flex', alignItems: 'center', border: '1px solid rgb(67, 67, 67)', padding: '10px', borderRadius: '8px', cursor: 'pointer', textDecoration: 'none' }}>Referral user : {e}</div>
          })}
        </div>
      </div>
    </>
  )
}

export default Stat
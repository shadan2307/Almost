import React from 'react'
import g from '../public/g.png'
const Referral = () => {
    const ReferralProgram = [{ user: 5, income: 20000 }, { user: 10, income: 100000 }, { user: 15, income: 20000000 }, { user: 20, income: 212000000 }]

    return (
        <>
            <div style={{ display: 'flex', gap: '20px', flexDirection: 'column' }}>

                {ReferralProgram.map((e) => {
                    return <div className='button' style={{ display: 'flex', alignItems: 'center', border: '1px solid rgb(67, 67, 67)', padding: '10px', borderRadius: '8px', cursor: 'pointer', textDecoration: 'none', justifyContent: 'space-between' }}>

                        <div style={{ display: 'flex', alignItems: 'center' }}> Refer {e.user} & Earn {e.income}    <img src={g} height={"10px"} alt="" /> </div> &nbsp;
                        <button style={{
                            cursor: 'pointer', border: 'none', padding: '7px', borderRadius: '4px', color: 'white',
                            backgroundColor: (e.user == 5 ? '#fe7326' : 'transparent'), border: (e.user == 5 ? 'none' : '1px solid grey')
                        }}>Claim</button>
                    </div>
                })}

            </div>


        </>
    )
}

export default Referral
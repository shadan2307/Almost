import React from 'react'
import { useState, useEffect } from 'react'
import './App.css'
import Loading from './Loading'
import coin from '../public/coin2.png'
import c from '../public/c.png'
import g from '../public/g.png'
import one from '../public/1.png'
import f from '../public/f.png'
import ss from '../public/ss.png'
import highVoltage from '../public/high-voltage.png';
import BackDrop from './BackDrop'
import t from '../public/t.png'
import s from '../public/s.png'
import r from '../public/r.png'
import { Link } from 'react-router-dom'
import Footer from './Footer'
import Booster from './Booster'
const Apps = () => {

  const [coin, setCoin] = useState(0)

  const [boostone, setboostone] = useState(0)


  const testBoost = () => {
    setboostone(1)
    setflyingNumber(120)

  }

  useEffect(() => {
    if (localStorage.getItem('coin')) {
      setCoin(parseInt(localStorage.getItem('coin')))
    } else {

    }

  }, [])
  const getCoin = () => {

    if (boostone) {
      localStorage.setItem('coin', coin + 120)
      setCoin(prevCoin => prevCoin + 120);
    } else {
      localStorage.setItem('coin', coin + 2)
      setCoin(prevCoin => prevCoin + 2);

    }




  }

  const [bot, setbot] = useState(0)




  const [animationCount, setAnimationCount] = useState(0);

  const [flyingNumber, setflyingNumber] = useState(2)

  const numberSize = 20;
  const animate = (event) => {
    const { clientX, clientY } = event;

    // Create a new div element for the number
    const number = document.createElement('div');
    number.textContent = flyingNumber;
    number.classList.add('number');
    number.style.fontSize = `${numberSize}px`; // Set font size
    number.style.left = `${clientX - numberSize / 2}px`; // Center horizontally
    number.style.top = `${clientY}px`; // Position vertically

    // Append the number to the document body
    document.body.appendChild(number);

    // Animate the number
    const animationName = animationCount % 2 === 0 ? 'flyingEven' : 'flyingOdd';
    number.style.animation = `${animationName} 0.8s linear`;

    // Remove the number from the DOM after animation ends
    number.addEventListener('animationend', () => {
      document.body.removeChild(number);
    });

    // Increment animation count for alternating animations
    setAnimationCount(prevCount => prevCount + 1);
  };


  const testBot = () => {

    const interval = setInterval(() => {

      setCoin(prevCoin => prevCoin + 103);
    }, 1000); // 1000 ms = 1 second

    // Clean up the interval to prevent memory leaks
    return () => clearInterval(interval);


  }


  return (
    <>



      <div style={{ display: 'flex', flexDirection: "column", justifyContent: 'center', alignItems: 'center', gap: '20px', border: '', padding: '60px 40px 60px 40px', borderRadius: '8px' }}>

        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '8px' }}>


          <img src={g} alt="" height={"30px"} width={"30px"} />
          <div style={{ fontSize: '30px', fontWeight: '600', color: 'white' }}>{coin && coin} M</div>

        </div>

        <Link to='/levels' style={{ color: 'white', textDecoration: 'none' }}> <img src={one} height={"20px"} alt="" />Legendary &gt; </Link>

        {/* <div style={{ height: '200px' }}></div> */}
        <div onClick={animate} className='coin'>
          <img style={{ paddingTop: '' }} onClick={getCoin} src={c} alt="" height={"200px"} width={"200px"} />
          {/* <img src={ss} alt="" /> */}
        </div>

        <div className='button' onClick={testBoost} style={{ padding: '10px', background: "", color: 'white', display: 'flex', justifyContent: 'center', alignItems: "center", cursor: 'pointer', border: '1px solid #434343', borderRadius: '8px' }}><img src={highVoltage} alt="" height={"20px"} width={"20px"} />&nbsp; Boost 120x</div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>

          <div className='button' onClick={testBot} style={{ padding: '10px', background: "", color: 'white', display: 'flex', justifyContent: 'center', alignItems: "center", cursor: 'pointer', border: '1px solid #434343', borderRadius: '8px' }}> Tap Bot </div>

        </div>
        <Booster></Booster>


      </div>



    </>
  )
}

export default Apps
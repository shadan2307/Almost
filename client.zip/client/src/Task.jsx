import React from 'react'

import utube from '../public/utube.png'
import c from '../public/c.png'
import g from '../public/g.png'
import twitter from '../public/twitter.png'
import whatsapp from '../public/whatsapp.png'
import { NavLink, Outlet } from 'react-router-dom'
// import { Referral, Follow, Youtube, DailyTask } from './'

const Task = () => {

  return (
    <>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '70px' }}>

        <div className="nav-container">
          <NavLink
            to="/task/dailytask"
            className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
          >
            Daily Task
          </NavLink>
          <NavLink
            to="/task/vid"
            className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
          >
            Earn
          </NavLink>
          <NavLink
            to="/task/ref"
            className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
          >
            Referrals
          </NavLink>
        </div>


        <div style={{
          height: '50vh'
        }}>
          <Outlet></Outlet>
        </div>

      </div>
    </>
  )
}

export default Task
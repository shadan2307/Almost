import React, { useState } from 'react'
import one from '../public/1.png'
import two from '../public/2.png'
import three from '../public/3.png'
import four from '../public/4.png'

const Levels = () => {


    const Level = [50000, 100000, 2000000, 25000000]
    const [imgData, setimgData] = useState(one);

    const forward = () => {

        if (imgData === one) {
            setimgData(two)
        } else if (imgData === two) {
            setimgData(three)
        } else if (imgData === three) {
            setimgData(four)
        }

    }

    const back = () => {
        if (imgData === four) {
            setimgData(three)
        } else if (imgData === three) {
            setimgData(two)
        } else if (imgData === two) {
            setimgData(one)
        }


    }


    return (
        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', gap: '50px' }}>

            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
                <div style={{ fontSize: '30px' }}>Bronze</div>
                <div>your share determine the level</div>
            </div>
            <div style={{ padding: '', display: 'flex' }}>
                {imgData === one ? <></> : <div onClick={back} style={{ cursor: 'pointer', backgroundColor: '', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '25px' }}>&lt;</div>}
                <div style={{
                    display: 'flex', justifyContent: 'center', alignItems: 'center'
                }}>

                    <img src={imgData} height={200} alt="" />

                </div>
                {imgData === four ? <></> :
                    <div onClick={forward} style={{ cursor: 'pointer', backgroundColor: '', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '25px' }}>&gt;</div>}
            </div>

            <div>FROM {imgData === one ? Level[0] : <></>} {imgData === two ? Level[1] : <></>}   {imgData === three ? Level[2] : <></>}  {imgData === four ? Level[3] : <></>}  </div>
            <div style={{
                backgroundColor: '#f9c035', borderRadius: '9px', width: '100%'
            }} >
                <div className='progress-fill' style={{ width: `${(260 / 500) * 100}%`, backgroundColor: 'green' }}></div>
            </div>


        </div>
    )
}

export default Levels
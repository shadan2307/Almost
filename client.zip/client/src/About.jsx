import React from 'react'

const About = ({ close }) => {
    return (
        <>
            <div style={{ height: '100vh', backgroundColor: '#242424', position: 'absolute', top: '0', left: '0', width: window.innerWidth, zIndex: '200', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', padding: '30px' }}>

                <h1>Hyper Cube</h1>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Rem praesentium maiores nobis dicta doloremque possimus vero distinctio quisquam? Enim consectetur voluptate corporis officia nobis ut unde distinctio quaerat illo? Sit dicta placeat obcaecati fuga accusantium aliquid, quibusdam quas et unde. Ad, aliquid.</p>


                <button className='button ' style={{ padding: '10px', backgroundColor: 'transparent', border: '1px solid grey', cursor: 'pointer', color: 'white' }} onClick={close}>Close</button>
            </div>
        </>
    )
}

export default About
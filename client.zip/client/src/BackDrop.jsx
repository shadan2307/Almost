import React from 'react'
import g from '../public/g.png'
// import coins from '../public/coins.gif'

const BackDrop = ({ close }) => {
  return (
    <>


    </>
  )
}

export default BackDrop
import React, { useEffect, useState } from 'react'
import Footer from './Footer'
import { Outlet } from 'react-router-dom'
import BackDrop from './BackDrop';
import Booster from './Booster'
import Loading from './Loading';
import About_Icon from './About_Icon';

const Home = () => {
    const [backdrop, setbackdrop] = useState(1);
    const closebackdrop = () => {
        setbackdrop(0)

    }

    const [showComponentA, setShowComponentA] = useState(true);
    useEffect(() => {
        const timeout = setTimeout(() => {
            setShowComponentA(false);
        }, 2000);

        return () => clearTimeout(timeout);
    }, []);


    return (
        <>
            <About_Icon />
            {showComponentA ? <Loading /> : <div id='home'>
                {!showComponentA && backdrop ? <BackDrop close={closebackdrop}></BackDrop> : <></>}
                <div style={{
                    display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh', maxWidth: 380
                }}>

                    <Outlet></Outlet>
                </div>

                <Footer></Footer>
            </div>}
        </>
    )
}

export default Home
import React from 'react'
import c from '../public/c.png'
import { Link } from 'react-router-dom'
import g from '../public/g.png'
import f from '../public/f.png'
import t from '../public/t.png'
import s from '../public/s.png'
import { Outlet } from 'react-router-dom'
import r from '../public/r.png'
const Footer = () => {
  return (
    <>

      <div style={{
        display: 'flex', alignItems: 'center', gap: '20px', position: '', bottom: '0px', backgroundColor: ''
      }}>





        <Link to='/home' className='button' style={{ textDecoration: "none", border: '1px solid #434343', borderRadius: '8px', padding: '10px', background: "", color: 'white', display: 'flex', justifyContent: 'center', alignItems: "center", cursor: 'pointer', flexDirection: 'column' }}><img src={r} alt="" height={"30px"} width={"30px"} /> <div style={{ fontSize: '11px' }}>Home</div></Link>



        <Link to='/task/dailytask' className='button' style={{ textDecoration: "none", border: '1px solid #434343', borderRadius: '8px', padding: '10px', background: "", color: 'white', display: 'flex', justifyContent: 'center', alignItems: "center", cursor: 'pointer', flexDirection: 'column' }}><img src={t} alt="" height={"30px"} width={"30px"} /> <div style={{ fontSize: '11px' }}>Task</div></Link>




        <Link to='/boost' className='button' style={{ textDecoration: "none", border: '1px solid #434343', borderRadius: '8px', padding: '10px', background: "", color: 'white', display: 'flex', justifyContent: 'center', alignItems: "center", cursor: 'pointer', flexDirection: 'column' }}><img src={f} alt="" height={"30px"} width={"30px"} /> <div style={{ fontSize: '11px' }}>Boost</div></Link>




        <Link to='/stat' className='button' style={{ textDecoration: "none", border: '1px solid #434343', borderRadius: '8px', padding: '10px', background: "", color: 'white', display: 'flex', justifyContent: 'center', alignItems: "center", cursor: 'pointer', flexDirection: 'column' }}><img src={s} alt="" height={"30px"} width={"30px"} /> <div style={{ fontSize: '11px' }}>Stat</div></Link>
      </div>

    </>
  )
}

export default Footer
// src/DailyButton.js
import React, { useState, useEffect } from 'react';
import Task_ from '../public/task_.png'
import g from '../public/g.png'

const DailyTask = () => {
    const DailyTask = [
        { day: 1, income: 200 },
        { day: 2, income: 400 },
        { day: 3, income: 600 },
        { day: 4, income: 800 },
        { day: 5, income: 1000 },
        { day: 6, income: 1200 },
        { day: 7, income: 1400 },
        { day: 8, income: 1600 },

    ]

    return (
        <>

            <div style={{ display: 'flex', gap: '7px', flexWrap: 'wrap', justifyContent: 'center', alignItems: 'center', width: 300 }}>
                {DailyTask.map((e) => {
                    return <span className='button' style={{ textDecoration: "none", border: '1px solid #434343', borderRadius: '8px', padding: '15px', background: "", color: 'white', display: 'flex', flexWrap: 'wrap', justifyContent: 'center', alignItems: "center", cursor: 'pointer', flexDirection: 'column', flex: "" }}>
                        <img src={Task_} alt="" height={"30px"} width={"30px"} />

                        <div style={{ fontSize: '11px' }}>{e.income} <img src={g} height={"10px"} alt="" /></div>
                        <div style={{ fontSize: '11px' }}>Day {e.day}</div>

                    </span>
                })}

            </div>

        </>
    );
};

export default DailyTask;

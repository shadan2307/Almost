import React from 'react'

const Follow = () => {
    return (
        <>
            <div>

                <div className='button' style={{ display: 'flex', alignItems: 'center', border: '1px solid rgb(67, 67, 67)', padding: '10px', borderRadius: '8px', cursor: 'pointer', textDecoration: 'none' }}>
                    {/* <img src={utube} height={"20px"} alt="" /> */}
                    <div style={{ display: 'flex', alignItems: 'center' }}> Watch Video & Earn  </div> &nbsp;
                    {/* <img src={g} height={"10px"} alt="" /> */}
                </div>

            </div>


        </>
    )
}

export default Follow